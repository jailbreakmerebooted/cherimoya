## git ##
git config --global http.sslCAInfo /var/jb/etc/ssl/certs/cacert.pem >/dev/null 2>&1
